import chimera.extension

class XlinkEMO(chimera.extension.EMO):
	def name(self):
		return "Crosslink Viewer"
	def description(self):
		return "Viewer for crosslink data"
	def categories(self):
		return ["Structure Analysis"]
	def activate(self):
		# Comment out if no GUI is needed
		from chimera.dialogs import display
		display(self.module("gui").XlinkDialog.name)
		return None

# Create extension manager object for this extension
emo = XlinkEMO(__file__)
chimera.extension.manager.registerExtension(emo)

class SplitEMO(chimera.extension.EMO):
	def name(self):
		return "Split Molecules"
	def description(self):
		return "Split molecules into multiple parts"
	def categories(self):
		return ["Structure Editing"]
	def activate(self):
		# Comment out if no GUI is needed
		from chimera.dialogs import display
		display(self.module("gui").SplitDialog.name)
		return None

# Create extension manager object for this extension
emo = SplitEMO(__file__)
chimera.extension.manager.registerExtension(emo)
