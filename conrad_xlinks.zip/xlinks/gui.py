# --- UCSF Chimera Copyright ---
# Copyright (c) 2006 Regents of the University of California.
# All rights reserved.  This software provided pursuant to a
# license agreement containing restrictions on its disclosure,
# duplication and use.  This notice must be embedded in or
# attached to all copies, including partial copies, of the
# software or any revisions or derivations thereof.
# --- UCSF Chimera Copyright ---

import chimera
from chimera.baseDialog import ModelessDialog

try:
	import xlrd
except ImportError:
	import sys, os.path
	sys.path.insert(0, os.path.join(os.path.dirname(__file__), "xlrd.zip"))
	import xlrd
	del sys.path[0]

class XlinkSheet(object):

	def __init__(self, parent, label=None):
		import Pmw, Tkinter
		if label is None:
			label = "Crosslink Excel Spreadsheet Selectors"
		self.group = Pmw.Group(parent, tag_text=label)
		f = self.group.interior()
		self.worksheet = Pmw.OptionMenu(f,
					labelpos="w",
					label_text="Worksheet:",
					command=self.newWorksheet,
					items=[])
		self.worksheet.pack(fill="x")
		self.accession1 = Pmw.OptionMenu(f,
					labelpos="w",
					label_text="Accession 1:",
					items=[])
		self.accession1.pack(fill="x")
		self.position1 = Pmw.OptionMenu(f,
					labelpos="w",
					label_text="Position 1:",
					items=[])
		self.position1.pack(fill="x")
		self.accession2 = Pmw.OptionMenu(f,
					labelpos="w",
					label_text="Accession 2:",
					items=[])
		self.accession2.pack(fill="x")
		self.position2 = Pmw.OptionMenu(f,
					labelpos="w",
					label_text="Position 2:",
					items=[])
		self.position2.pack(fill="x")
		self.attrColumns = Pmw.ScrolledListBox(f,
					labelpos="w",
					label_text="Attribute Columns:",
					listbox_selectmode="extended",
					listbox_height=5,
					items=[])
		self.attrColumns.pack(fill="x")
		Pmw.alignlabels((self.worksheet, self.accession1,
					self.position1, self.accession2,
					self.position2, self.attrColumns),
					sticky="e")
		self.wb = None
		self.ws = None

	def newWorksheet(self, wsName):
		if not self.wb:
			self.ws = None
			return
		self.ws = self.wb.sheet_by_name(wsName)
		from crosslink import get_column_map
		self.columnMap = get_column_map(self.ws)
		cols = self.columnMap.keys()
		cols.sort()
		oldAccession1 = self.accession1.getvalue()
		oldPosition1 = self.position1.getvalue()
		oldAccession2 = self.accession2.getvalue()
		oldPosition2 = self.position2.getvalue()
		oldAttrColumns = self.attrColumns.getvalue()
		newAccession1 = self._getOption(self.columnMap, oldAccession1,
							"pep1.accession")
		newPosition1 = self._getOption(self.columnMap, oldPosition1,
							"pep1.xlinked_aa")
		newAccession2 = self._getOption(self.columnMap, oldAccession2,
							"pep2.accession")
		newPosition2 = self._getOption(self.columnMap, oldPosition2,
							"pep2.xlinked_aa")
		newAttrColumns = [ a for a in oldAttrColumns
						if a in self.columnMap ]
		if not newAttrColumns:
			newAttrColumns = [ cols[0] ]
		self.accession1.setitems(cols)
		self.accession1.setvalue(newAccession1)
		self.position1.setitems(cols)
		self.position1.setvalue(newPosition1)
		self.accession2.setitems(cols)
		self.accession2.setvalue(newAccession2)
		self.position2.setitems(cols)
		self.position2.setvalue(newPosition2)
		self.attrColumns.setlist(cols)
		self.attrColumns.setvalue(newAttrColumns)

	def _getOption(self, cols, old, default):
		if old in cols:
			return old
		if default in cols:
			return default
		return ""

	def setExcel(self, excelName):
		import xlrd
		try:
			self.wb = xlrd.open_workbook(excelName)
		except xlrd.XLRDError as e:
			from chimera import replyobj
			replyobj.error("Cannot open %s: %s" %
						(excelName, str(e)))
			return
		oldSheet = self.worksheet.getvalue()
		sheets = self.wb.sheet_names()
		self.worksheet.setitems(sheets)
		if oldSheet in sheets:
			newSheet = oldSheet
		else:
			newSheet = sheets[0]
			self.worksheet.setvalue(newSheet)
		self.newWorksheet(newSheet)

	def getXlinkList(self):
		reqColumns = ( self.accession1.getvalue(),
				self.position1.getvalue(),
				self.accession2.getvalue(),
				self.position2.getvalue() )
		def _attrName(a):
			return ''.join([ c for c in a
					if (c.isalnum() or c == "_") ])
		attrs = self.attrColumns.getvalue()
		valColumns = dict([ ( a, _attrName(a) ) for a in attrs ])
		from crosslink import get_crosslinks
		from viewer import Xlink
		xlinkList = [ Xlink(*args)
				for args in get_crosslinks(self.wb,
								self.ws.name,
								reqColumns,
								valColumns) ]
		return xlinkList, valColumns

class XlinkDialog(ModelessDialog):
	name = "Crosslink Viewer Open Dialog"
	help = "ContributedSoftware/xlinks/xlinks.html"

	def fillInUI(self, parent):
		# Fill in Tkinter user interface in parent frame
		parent.columnconfigure(0, weight=0)
		parent.columnconfigure(1, weight=1)

		from chimera.tkoptions import InputFileOption
		self.inputFasta = InputFileOption(parent, 0,
					"Reference Sequences FASTA File",
					None, None)
		self.inputExcel = InputFileOption(parent, 1,
					"Crosslink Excel Spreadsheet",
					None, self.newSpreadsheet)
		self.xlinkSheet = XlinkSheet(parent)
		self.xlinkSheet.group.grid(row=2, column=0, columnspan=2,
						sticky="ew")

	def newSpreadsheet(self, opt):
		self.xlinkSheet.setExcel(opt.get())

	def Apply(self):
		inputFasta = self.inputFasta.get()
		if not inputFasta:
			from chimera import replyobj
			replyobj.error("No FASTA file selected")
			return
		inputExcel = self.inputExcel.get()
		if not inputExcel:
			from chimera import replyobj
			replyobj.error("No Excel file selected")
			return
		import refseq
		seqs = refseq.get_seqs(inputFasta)
		from viewer import XlinkViewer
		xv = XlinkViewer(inputExcel, seqs)
		xlinkList, valColumns = self.xlinkSheet.getXlinkList()
		xv.xlinkSetData(xlinkList, valColumns)

class SplitDialog(ModelessDialog):
	name = "Split Molecules"

	def fillInUI(self, parent):
		# Fill in Tkinter user interface in parent frame
		from chimera.tkoptions import MoleculeOption, EnumOption
		class SplitOption(EnumOption):
			values = ("chains", "ligands", "connected", "selected")
			default = values[0]
		self.molOption = MoleculeOption(parent, 0, "Molecule to Split",
						None, None)
		self.splitOption = SplitOption(parent, 1, "Split Method",
						None, None)

	def Apply(self):
		mol = self.molOption.get()
		opt = self.splitOption.get()
		if opt == "selected":
			args = "atoms sel"
		else:
			args = opt
		from SplitMolecule import split_command
		split_command("split", "%s %s" % (mol.oslIdent(), args))

from chimera import dialogs
dialogs.register(XlinkDialog.name, XlinkDialog)
dialogs.register(SplitDialog.name, SplitDialog)
