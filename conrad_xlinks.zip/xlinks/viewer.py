class Xlink(object):
	"""Class for one cross link."""
	def __init__(self, r1_id, r1_pos, r2_id, r2_pos, values):
		self.r1_id = r1_id
		self.r1_pos = r1_pos
		self.r1_residue = None
		self.r2_id = r2_id
		self.r2_pos = r2_pos
		self.r2_residue = None
		self.scores = values
		self._pb = None

	def __str__(self):
		return "%s.%d-%s.%d" % (self.r1_id, self.r1_pos,
						self.r2_id, self.r2_pos)

	def set_residues(self, r1, r2):
		import weakref
		self.r1_residue = weakref.proxy(r1, self._del_r1)
		self.r2_residue = weakref.proxy(r2, self._del_r2)
		# print "linking", self.r1_pos, r1.oslIdent(), \
		#		r1.type, self.r2_pos, r2.oslIdent(), r2.type

	def clear_residues(self):
		self.r1_residue = None
		self.r2_residue = None

	def _del_r1(self, ignore):
		self.r1_residue = None

	def _del_r2(self, ignore):
		self.r2_residue = None

	def makePseudobond(self, pbg):
		if not self.r1_residue or not self.r2_residue:
			self._pb = None
			return None
		try:
			a1 = self._find_atom(self.r1_residue)
			a2 = self._find_atom(self.r2_residue)
		except IndexError:
			self._pb = None
			return None
		else:
			pb = pbg.newPseudoBond(a1, a2)
			import weakref
			self._pb = weakref.ref(pb)
			return pb

	def pseudobond(self):
		if self._pb is None:
			return None
		return self._pb()

	def _find_atom(self, r):
		for name in [ "CA", "P" ]:
			a = r.findAtom(name)
			if a:
				return a
		return r.atoms[0]

	def wanted(self, isIntra, isInter, isUnmapped):
		if self.r1_residue and self.r2_residue:
			if isUnmapped:
				return False
			if self.r1_residue.molecule is self.r2_residue.molecule:
				return isIntra
			else:
				return isInter
		else:
			if isUnmapped:
				return True
			return False

from MultAlignViewer import MAViewer
class XlinkViewer(MAViewer.MAViewer):
	"""Class for displaying cross link data."""
	title = "Crosslink Viewer"
	XLINK_NO_DATA = "no cross-link data"
	XLINK_PBG_PREFIX = "Cross links from"

	def __init__(self, xlinkName="crosslinks", *args, **kw):
		self.xlinkName = xlinkName
		self.xlinkList = []
		self.xlinkAttrs = {}
		self.xlinkWarned = False
		self.xlinkPbg = "%s %s" % (self.XLINK_PBG_PREFIX, xlinkName)
		self.xlinkPbs = {}
		MAViewer.MAViewer.__init__(self, *args, **kw)
		self.hideHeaders(self.headers(shownOnly=True))

	def customUI(self, parent):
		# Create top section of histogram and options
		import Tkinter, Pmw
		f = Tkinter.Frame(parent)

		# Which crosslinks to display
		bf = Tkinter.Frame(f)
		bf.pack(fill="x")
		Tkinter.Label(bf, text="Show: ").pack(side="left")
		self.xlinkShowIntra = Tkinter.IntVar(parent)
		self.xlinkShowIntra.set(True)
		b = Tkinter.Checkbutton(bf, text="intra-model",
						variable=self.xlinkShowIntra,
						command=self._xlinkStatsCB)
		b.pack(side="left")
		self.xlinkShowInter = Tkinter.IntVar(parent)
		self.xlinkShowInter.set(True)
		b = Tkinter.Checkbutton(bf, text="inter-model",
						variable=self.xlinkShowInter,
						command=self._xlinkStatsCB)
		b.pack(side="left")
		self.xlinkShowUnmapped = Tkinter.IntVar(parent)
		self.xlinkShowUnmapped.set(True)
		b = Tkinter.Checkbutton(bf, text="unmapped",
						variable=self.xlinkShowUnmapped,
						command=self._xlinkStatsCB)
		b.pack(side="left")
		Tkinter.Label(bf, text=" crosslinks").pack(side="left")

		# Score histogram
		f.pack(fill="both")
		self.xlinkAttrOption = Pmw.OptionMenu(f, labelpos="w",
						label_text="Score",
						command=self.xlinkUpdate)
		self.xlinkAttrOption.pack(anchor="n")
		from CGLtk.Histogram import MarkedHistogram
		self.xlinkHistogram = MarkedHistogram(f,
						datasource=self.XLINK_NO_DATA,
						scaling="linear")
		self.xlinkHistogram.pack(anchor="n", fill="x")
		self.xlinkMarkers = None

		# Action buttons
		bf = Tkinter.Frame(f)
		bf.pack(fill="x")
		rb = Tkinter.Button(bf, text="Replace Pseudobonds",
						state="disabled",
						command=self.xlinkReplacePB)
		rb.pack(side="right", padx=3, pady=2)
		ab = Tkinter.Button(bf, text="Add Pseudobonds",
						state="disabled",
						command=self.xlinkAddPB)
		ab.pack(side="right", padx=3, pady=2)
		hb = Tkinter.Button(bf, text="Highlight Table Rows",
						state="disabled",
						command=self.xlinkHighlightRows)
		hb.pack(side="right", padx=3, pady=2)
		self.xlinkButtons = [ hb, ab, rb ]

		# Create notebook and return one of the tabs for MAV sequences
		self.xlinkNotebook = Pmw.NoteBook(parent)
		self.xlinkNotebook.pack(fill="both", expand=True)
		self.xlinkTablePage = self.xlinkNotebook.add("Crosslinks")
		self.xlinkTable = None
		# To be filled in when xlinkSetData is called
		page = self.xlinkNotebook.add("Reference Sequences")
		return page

	def fillInUI(self, parent):
		MAViewer.MAViewer.fillInUI(self, parent)
		# Create crosslink menu and menu items
		import Tkinter
		self.xlinkMenu = Tkinter.Menu(self.menuBar)
		self.menuBar.add_cascade(label="Crosslinks",
						menu=self.xlinkMenu)
		self.xlinkAddXlinkDialog = None
		self.xlinkMenu.add_command(label="Add Crosslinks...",
						command=self._addCrosslinks)
		self.xlinkMenu.add_command(label="Split Molecules...",
						command=self._splitMolecules)

	def _addCrosslinks(self):
		if self.xlinkAddXlinkDialog:
			self.xlinkAddXlinkDialog.enter()
		else:
			self.xlinkAddXlinkDialog = AddXlinkDialog(self)

	def _splitMolecules(self):
		from chimera import dialogs
		from gui import SplitDialog
		dialogs.find(SplitDialog.name, create=True).enter()

	def xlinkSetData(self, xlinkList, attrs):
		self.xlinkAttrs.update(attrs)
		self.xlinkList.extend(xlinkList)
		if not self.xlinkList:
#			self.xlinkHistogram["datasource"] = self.XLINK_NO_DATA
#			self.xlinkUpdateStates("disabled")
			val = None
		else:
			val = self.xlinkAttrOption.getcurselection()
			items = attrs.keys()
			self.xlinkAttrOption.setitems(items)
			if not val:
				val = items[0]
				self.xlinkAttrOption.setvalue(items[0])
			self.xlinkMap()
		if self.xlinkTable:
			self.xlinkTable.destroy()
			self.xlinkTable = None
		from CGLtk import Table
		self.xlinkTable = Table.SortableTable(self.xlinkTablePage)
		def getOSL(xlink, attr):
			r = getattr(xlink, attr)
			return r and r.oslIdent() or "-"
		def getOSL1(xlink): return getOSL(xlink, "r1_residue")
		def getOSL2(xlink): return getOSL(xlink, "r2_residue")
		def getScore(xlink, score):
			try:
				return "%5.2f" % xlink.scores[score]
			except KeyError:
				return "-"
		self.xlinkTable.pack(fill="both", expand=True)
		self.xlinkTable.addColumn(" Sequence 1 ", "r1_id",
						format="%s ",
						anchor="w",
						headerAnchor="center")
		self.xlinkTable.addColumn(" Position 1 ", "r1_pos",
						format="%5d ",
						anchor="e",
						headerAnchor="center")
		self.xlinkTable.addColumn(" Residue 1 ", getOSL1,
						format="%s ",
						anchor="w",
						headerAnchor="center")
		self.xlinkTable.addColumn(" Sequence 2 ", "r2_id",
						format="%s ",
						anchor="w",
						headerAnchor="center")
		self.xlinkTable.addColumn(" Position 2 ", "r2_pos",
						format="%5d ",
						anchor="e",
						headerAnchor="center")
		self.xlinkTable.addColumn(" Residue 2 ", getOSL2,
						format="%s ",
						anchor="w",
						headerAnchor="center")
		scoreNames = set()
		for xlink in self.xlinkList:
			scoreNames.update(xlink.scores.keys())
		for score in sorted(scoreNames):
			def get(xlink, score=score):
				return getScore(xlink, score)
			self.xlinkTable.addColumn(" %s " % score, get,
							format="%s ",
							anchor="e",
							headerAnchor="center")
#		self.xlinkTable.setData(self.xlinkList)
		self.xlinkUpdate(val)	# updates button states
		self.xlinkTable.launch(browseCmd=self._xlinkBrowseCB)

	def _xlinkBrowseCB(self, selected):
		pbList = []
		for xlink in selected:
			pb = xlink.pseudobond()
			if pb:
				pbList.append(pb)
		if not pbList:
			return
		from chimera import selection
		selection.clearCurrent()
		selection.addCurrent(pbList)
		selection.addImpliedCurrent()
		import chimera
		chimera.runCommand("focus sel")

	def _xlinkStatsCB(self):
		val = self.xlinkAttrOption.getcurselection()
		self.xlinkUpdate(val)

	def xlinkUpdate(self, label):
		showIntra = self.xlinkShowIntra.get()
		showInter = self.xlinkShowInter.get()
		showUnmapped = self.xlinkShowUnmapped.get()
		xlinks = [ xlink for xlink in self.xlinkList
			if xlink.wanted(showIntra, showInter, showUnmapped) ]
		self.xlinkTable.setData(xlinks)
		try:
			if not xlinks:
				raise KeyError("no xlink data")
			attr = self.xlinkAttrs[label]
		except KeyError:
			self.xlinkValues = None
			self.xlinkHistogram["datasource"] = self.XLINK_NO_DATA
			if self.xlinkMarkers:
				self.xlinkHistogram.deletemarkers(
							self.xlinkMarkers)
				self.xlinkMarkers = None
			self.xlinkUpdateStates("disabled")
		else:
			self.xlinkValues = [ xlink.scores[attr]
						for xlink in xlinks
						if attr in xlink.scores ]
			lo = min(self.xlinkValues)
			hi = max(self.xlinkValues)
			self.xlinkHistogram["datasource"] = ( lo, hi,
							self.xlinkBins )
			if self.xlinkMarkers:
				self.xlinkHistogram.deletemarkers(
							self.xlinkMarkers)
			self.xlinkMarkers = self.xlinkHistogram.addmarkers(
							minmarks=2,
							maxmarks=2)
			self.xlinkMarkers.append( ((lo, self.xlinkValues[0]),
							None) )
			self.xlinkMarkers.append( ((hi, self.xlinkValues[-1]),
							None) )
			self.xlinkUpdateStates("normal")

	def xlinkUpdateStates(self, state):
		self.xlinkAttrOption.configure(menubutton_state=state)
		for b in self.xlinkButtons:
			b.config(state=state)

	def xlinkBins(self, width):
		bins = max(int(width / 5), 1)
		ds = self.xlinkHistogram["datasource"]
		lo = ds[0]
		hi = ds[1]
		interval = (hi - lo) / bins
		counts = [0] * bins
		for v in self.xlinkValues:
			try:
				counts[int((v - lo) / interval)] += 1
			except IndexError:
				# The element matching "hi" is out index range
				counts[-1] += 1
		return counts

	def xlinkAddPB(self):
		if self.xlinkMarkers is None:
			return
		showIntra = self.xlinkShowIntra.get()
		showInter = self.xlinkShowInter.get()
		xlinks = [ xlink for xlink in self.xlinkList
				if xlink.wanted(showIntra, showInter, False) ]
		if not xlinks:
			return
		# Create pseudobond group
		from chimera.misc import getPseudoBondGroup
		pbg = getPseudoBondGroup(self.xlinkPbg)
		# Get upper and lower bounds and colors
		x0 = self.xlinkMarkers[0]["xy"][0]
		rgba0 = self.xlinkMarkers[0]["rgba"]
		x1 = self.xlinkMarkers[1]["xy"][0]
		rgba1 = self.xlinkMarkers[1]["rgba"]
		if x0 < x1:
			hi, lo, hi_rgba, lo_rgba = x1, x0, rgba0, rgba1
		else:
			hi, lo, lo_rgba, hi_rgba = x0, x1, rgba0, rgba1
		hi_lo = float(hi - lo)
		def interp(v):
			f = (v - lo) / hi_lo
			return [ f * lo_rgba[i] + (1 - f) * hi_rgba[i]
					for i in range(4) ]
		# Create pseudobonds for xlinks in selected range
		attr = self.xlinkAttrs[self.xlinkAttrOption.getcurselection()]
		from chimera import MaterialColor
		for xlink in xlinks:
			try:
				v = xlink.scores[attr]
			except ValueError:
				continue
			else:
				if v < lo or v > hi:
					continue
			try:
				pb = self.xlinkPbs[xlink]
			except KeyError:
				pb = xlink.makePseudobond(pbg)
			if not pb:
				continue
			pb.color = MaterialColor(*interp(v))
			self.xlinkPbs[xlink] = pb

	def xlinkReplacePB(self):
		if self.xlinkMarkers is None:
			return
		# Delete current pseudobonds
		self.xlinkPbs = {}
		from chimera.misc import getPseudoBondGroup
		pbg = getPseudoBondGroup(self.xlinkPbg, create=False)
		if pbg is not None:
			from chimera import PseudoBondMgr
			PseudoBondMgr.mgr().deletePseudoBondGroup(pbg)
		self.xlinkAddPB()

	def xlinkHighlightRows(self):
		# Get upper and lower bounds and colors
		x0 = self.xlinkMarkers[0]["xy"][0]
		x1 = self.xlinkMarkers[1]["xy"][0]
		if x0 < x1:
			hi, lo = x1, x0
		else:
			hi, lo = x0, x1
		attr = self.xlinkAttrs[self.xlinkAttrOption.getcurselection()]
		hlList = []
		for xlink in self.xlinkList:
			try:
				v = xlink.scores[attr]
			except ValueError:
				continue
			else:
				if v < lo or v > hi:
					continue
			hlList.append(xlink)
		self.xlinkTable.highlight(hlList)

	def xlinkMap(self):
		# Map xlink residues to structure residues
		seq_map = dict([ (seq.referenceName, seq)
					for seq in self.seqs ])
		unmappable = []
		multiple = []
		mapped = []
		for xlink in self.xlinkList:
			if (xlink.r1_id == xlink.r2_id
					and xlink.r1_pos == xlink.r2_pos):
				print "Degenerate cross link:", xlink
				unmappable.append(xlink)
				continue
			s1 = seq_map[xlink.r1_id]
			s2 = seq_map[xlink.r2_id]
			try:
				if (len(s1.matchMaps) == 0
						or len(s2.matchMaps) == 0):
					raise AttributeError("no match")
			except AttributeError:
				unmappable.append(xlink)
				xlink.clear_residues()
				continue
			if len(s1.matchMaps) > 1 or len(s2.matchMaps) > 1:
				multiple.append(xlink)
				xlink.clear_residues()
				continue
			s1map = s1.matchMaps.values()[0]
			s2map = s2.matchMaps.values()[0]
			# The cross link positions refers to the
			# ungapped reference sequences (1-based), as does
			# the sequence matchMaps (0-based).  So we can use
			# the positions as dictionary keys, after
			# correcting for the bases.
			r1 = s1map.get(xlink.r1_pos - 1, None)
			r2 = s2map.get(xlink.r2_pos - 1, None)
			if r1 is None or r2 is None:
				xlink.clear_residues()
				unmappable.append(xlink)
			else:
				xlink.set_residues(r1, r2)
				mapped.append(xlink)
		print "%d cross links mapped" % len(mapped)
		if unmappable:
			print "%d cross links do not map to structure" % len(unmappable)
			#for xlink in unmappable:
			#	print " ", xlink
		if multiple:
			print "%d cross links map to multiple structures" % len(multiple)
			#for xlink in multiple:
			#	print " ", xlink
		if not self.xlinkWarned and len(mapped) != len(self.xlinkList):
			from chimera.replyobj import warning
			warning("Some cross links cannot be mapped; "
					"see Reply Log for details.");
			self.xlinkWarned = True

	# Override the default "associate" method so that we
	# can up date our Xlink list with more/less residues
	def associate(self, models, *args, **kw):
		MAViewer.MAViewer.associate(self, models, *args, **kw)
		# Do not bother updating if the model added
		# is the one we just changed
		if len(models) == 1:
			from chimera.misc import getPseudoBondGroup
			pbg = getPseudoBondGroup(self.xlinkPbg, create=False)
			if models[0] == pbg:
				return
		if self.xlinkList:
			self.xlinkMap()
			val = self.xlinkAttrOption.getcurselection()
			self.xlinkUpdate(val)

from chimera.baseDialog import ModelessDialog
class AddXlinkDialog(ModelessDialog):

	def __init__(self, xlinkViewer, *args, **kw):
		self.viewer = xlinkViewer
		self.title = "Add to %s" % xlinkViewer.xlinkName
		ModelessDialog.__init__(self, *args, **kw)

	def fillInUI(self, parent):
		parent.columnconfigure(0, weight=0)
		parent.columnconfigure(1, weight=1)
		from chimera.tkoptions import InputFileOption
		self.inputExcel = InputFileOption(parent, 0,
					"Crosslink Excel Spreadsheet",
					None, self.newSpreadsheet)
		import gui
		self.xlinkSheet = gui.XlinkSheet(parent)
		self.xlinkSheet.group.grid(row=1, column=0, columnspan=2,
						sticky="ew")

	def newSpreadsheet(self, opt):
		self.xlinkSheet.setExcel(opt.get())

	def Apply(self):
		xlinkList, valColumns = self.xlinkSheet.getXlinkList()
		self.viewer.xlinkSetData(xlinkList, valColumns)
		ModelessDialog.Apply(self)
