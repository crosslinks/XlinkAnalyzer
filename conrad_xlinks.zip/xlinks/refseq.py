"""Read reference sequences from FASTA file.

Assumptions:
	FASTA file descriptions are split by '|'
	First component of description is the unique key for the sequence
"""

def get_seqs(fasta_filename):
	"Returns a list of sequences compatible with MultAlignViewer."

	from MultAlignViewer import parse
	seqs, fileAttrs, fileMarkups = parse.parseFile(fasta_filename,
							"Aligned FASTA",
							minSeqs=1,
							uniformLength=False)
	max_length = max([ len(seq.sequence) for seq in seqs ])
	for seq in seqs:
		while len(seq.sequence) < max_length:
			seq.append('-')
		seq.referenceName = seq.name.split('|', 1)[0]
	return seqs

if __name__ in ( "__main__", "chimeraOpenSandbox" ):
	fasta_filename = "polii.fasta"
	seqs = get_seqs(fasta_filename)
	for seq in seqs:
		print "reference name", seq.referenceName
