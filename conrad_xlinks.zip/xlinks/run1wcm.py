import sys
sys.path.insert(0, "xlrd.zip")
sys.path.insert(0, ".")

from viewer import Xlink, XlinkViewer

# Open structure model
import chimera
mol_list = chimera.openModels.open("1wcm", "PDBID")

# Split models by chain
from SplitMolecule.split import split_molecules
split_molecules(mol_list, chains=True)
import chimera
chimera.runCommand("rainbow models")

# Read FASTA reference sequences for xlinks
import sys, os
import refseq
seqs = refseq.get_seqs("polii.fasta")

worksheet = "Unique"
res_columns = (
	"pep1.accession",
	"pep1.xlinked_aa",
	"pep2.accession",
	"pep2.xlinked_aa" )
val_columns = {
	"SVM dval": "SVM",
	"dists (CA)": "distance",
	"no spect": "num_spectra",
}

# Read cross link data
import xlrd
filename = "polii_xlinks_for_riccardo.xlsx"
wb = xlrd.open_workbook(filename)
from crosslink import get_crosslinks
xlink_list = [ Xlink(*args) for args in get_crosslinks(wb, worksheet,
						res_columns, val_columns) ]

mav = XlinkViewer(filename, seqs)
mav.xlinkSetData(xlink_list, val_columns)
