"""Read crosslink data from Excel file.

Assumptions:
	Crosslink data is stored in a single worksheet.
	First row in worksheet contains column names
	Each residue is specified in two columns
		Model id - matches an id of a reference sequence
		Residue position - offset within reference sequence
	'xlrd' package is available

Typical usage:

	worksheet = "Unique"
	residue_columns = (
		"pep1.accession",
		"pep1.xlinked_aa",
		"pep2.accession",
		"pep2.xlinked_aa" )
	additional_attributes = {
		"SVM dval": "score",
		"dists (CA)": "distance",
		"no spect": "num_spectra",
	}

	import xlrd
	wb = xlrd.open_workbook(excel_filename)
	for xlink in get_crosslinks(wb, worksheet, residue_columns,
						additional_attributes):
		r1_id, r1_pos, r2_id, r2_pos, attrs = xlink
		print "crosslink: %s %d %s %d" % (r1_id, r1_pos, r2_id, r2_pos)
		for attr, val in attrs.iteritems():
			print "\t%s: %s" % (attr, val)
"""

def get_crosslinks(wb, worksheet, residue_columns, additional_attributes):
	ws = wb.sheet_by_name(worksheet)
	title_map = get_column_map(ws)
	required_names = [ "r1_id", "r1_pos", "r2_id", "r2_pos" ]
	if len(residue_columns) != len(required_names):
		raise ValueError("wrong number of required specifiers")
	required_attributes = zip(residue_columns, required_names)
	try:
		req_columns = [ title_map[column_name]
				for column_name, attr_name
				in required_attributes ]
		opt_attrs = [ (title_map[column_name], attr_name)
				for column_name, attr_name
				in additional_attributes.iteritems() ]
	except KeyError, e:
		raise ValueError("column \"%s\" is not in the worksheet" % e)
	from xlrd import XL_CELL_NUMBER
	for row in range(1, ws.nrows):
		req = [ ws.cell_value(row, col) for col in req_columns ]
		# Convert position to integer
		req[1] = int(req[1])
		req[3] = int(req[3])
		if req[0] == req[2] and req[1] == req[3]:
			# Identical ends
			print "Degenerate link: %s.%s - %s.%s" % tuple(req)
			continue
		opt = dict([ (attr_name, ws.cell_value(row, col))
				for col, attr_name in opt_attrs
				if ws.cell_type(row, col) == XL_CELL_NUMBER ])
		req.append(opt)
		yield req

def get_column_map(ws):
	return dict([ (name, col)
			for col, name in enumerate(ws.row_values(0)) ])

if __name__ in ( "__main__", "chimeraOpenSandbox" ):
	excel_filename = "polii_xlinks_for_riccardo.xlsx"

	worksheet = "Unique"
	residue_columns = (
		"pep1.accession",
		"pep1.xlinked_aa",
		"pep2.accession",
		"pep2.xlinked_aa" )
	additional_attributes = {
		"SVM dval": "score",
		"dists (CA)": "distance",
		"no spect": "num_spectra",
	}

	import xlrd
	wb = xlrd.open_workbook(excel_filename)
	for xlink in get_crosslinks(wb, worksheet, residue_columns,
						additional_attributes):
		r1_id, r1_pos, r2_id, r2_pos, attrs = xlink
		print "crosslink: %s %d %s %d" % (r1_id, r1_pos, r2_id, r2_pos)
		for attr, val in attrs.iteritems():
			print "\t%s: %s" % (attr, val)
